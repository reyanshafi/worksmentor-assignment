// worksmentor-assignment/js/main.js

// --- 1. Mock Data ---
const projects = [
    {
        id: 1,
        title: "Full Apartment Renovation",
        category: "Renovation",
        location: "Mumbai",
        description: "Looking for a team to renovate a 2BHK apartment in Bandra West. Includes flooring, painting, and modular kitchen installation.",
        budget: 450000,
        postedDate: "2026-02-15"
    },
    {
        id: 2,
        title: "Kitchen Plumbing Fix",
        category: "Plumbing",
        location: "Delhi",
        description: "Need an experienced plumber to fix a leaking sink and install a new water purifier connection.",
        budget: 5000,
        postedDate: "2026-02-16"
    },
    {
        id: 3,
        title: "Exterior Wall Painting",
        category: "Painting",
        location: "Bangalore",
        description: "Paint the exterior of a 3-story building. Weather-proof paint required. Approx 4000 sq ft.",
        budget: 120000,
        postedDate: "2026-02-14"
    },
    {
        id: 4,
        title: "Office Electrical Wiring",
        category: "Electrical",
        location: "Pune",
        description: "Setting up a new office space. Need complete wiring for 20 workstations, server room, and lighting.",
        budget: 85000,
        postedDate: "2026-02-10"
    },
    {
        id: 5,
        title: "Custom Wooden Wardrobe",
        category: "Carpentry",
        location: "Mumbai",
        description: "Design and build a custom floor-to-ceiling wardrobe for the master bedroom. Teak wood finish preferred.",
        budget: 65000,
        postedDate: "2026-02-12"
    },
    {
        id: 6,
        title: "Bathroom Tile Replacement",
        category: "Renovation",
        location: "Delhi",
        description: "Remove old tiles and install new anti-skid tiles in two bathrooms. Material will be provided.",
        budget: 25000,
        postedDate: "2026-02-11"
    },
    {
        id: 7,
        title: "Living Room False Ceiling",
        category: "Renovation",
        location: "Bangalore",
        description: "Gypsum false ceiling with cove lighting for a 400 sq ft living room. Modern design required.",
        budget: 45000,
        postedDate: "2026-02-13"
    },
    {
        id: 8,
        title: "Emergency Circuit Breaker Fix",
        category: "Electrical",
        location: "Mumbai",
        description: "Main circuit breaker keeps tripping. Need an electrician immediately to diagnose and fix the issue.",
        budget: 2000,
        postedDate: "2026-02-17"
    }
];

// --- 2. State Management ---
let state = {
    filters: {
        category: 'all',
        location: 'all',
        minBudget: 0
    },
    sortBy: 'newest'
};

// --- 3. DOM Elements ---
const dom = {
    grid: document.getElementById('project-grid'),
    count: document.getElementById('result-count'),
    noResults: document.getElementById('no-results'),
    inputs: {
        category: document.getElementById('category-filter'),
        location: document.getElementById('location-filter'),
        budget: document.getElementById('budget-range'),
        sort: document.getElementById('sort-select')
    },
    displays: {
        budget: document.getElementById('budget-display')
    },
    buttons: {
        clear: document.getElementById('clear-filters'),
        reset: document.getElementById('reset-filters-btn')
    }
};

// --- 4. Render Functions ---

// Format currency to Indian Rupee
const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumSignificantDigits: 3
    }).format(amount);
};

// Create HTML for a single project card
const createCard = (project) => {
    const timeAgo = new Date(project.postedDate).toLocaleDateString();

    return `
        <article class="card flex flex-col p-0 overflow-hidden group">
            <div class="p-5 flex justify-between items-start border-b border-gray-100 bg-gray-50/50">
                <span class="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-blue-100 text-primary hover:bg-blue-200">${project.category}</span>
                <span class="text-xs font-medium text-slate-400">${timeAgo}</span>
            </div>
            
            <div class="px-6 py-5 flex-grow">
                <h3 class="text-lg font-bold text-slate-900 mb-2 leading-tight group-hover:text-primary transition-colors cursor-pointer">
                    ${project.title}
                </h3>
                <div class="flex items-center gap-2 text-sm text-slate-500 mb-4 font-medium">
                    <svg class="h-4 w-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                    </svg>
                    <span>${project.location}</span>
                </div>
                <p class="text-sm text-slate-600 line-clamp-3 leading-relaxed">
                    ${project.description}
                </p>
            </div>

            <div class="mt-auto px-6 py-4 border-t border-slate-100 bg-white flex justify-between items-center">
                <span class="text-lg font-bold text-slate-900 tracking-tight">${formatCurrency(project.budget)}</span>
                <button class="text-sm font-semibold text-primary hover:text-primary-hover hover:underline transition-all flex items-center gap-1 group/btn">
                    View Details 
                    <span class="group-hover/btn:translate-x-1 transition-transform">→</span>
                </button>
            </div>
        </article>
    `;
};

// Filter and Sort Logic
const getFilteredProjects = () => {
    let result = projects.filter(p => {
        // Category Filter
        if (state.filters.category !== 'all' && p.category !== state.filters.category) return false;
        // Location Filter
        if (state.filters.location !== 'all' && p.location !== state.filters.location) return false;
        // Budget Filter
        if (p.budget < state.filters.minBudget) return false;

        return true;
    });

    // Sorting
    result.sort((a, b) => {
        if (state.sortBy === 'newest') {
            return new Date(b.postedDate) - new Date(a.postedDate);
        } else if (state.sortBy === 'budget-high') {
            return b.budget - a.budget;
        } else if (state.sortBy === 'budget-low') {
            return a.budget - b.budget;
        }
    });

    return result;
};

// Main Render Function
const render = () => {
    const filtered = getFilteredProjects();

    // Update Count
    dom.count.innerText = filtered.length === 1 ? '1 Project' : `${filtered.length} Projects`;

    // Toggle Empty State
    if (filtered.length === 0) {
        dom.grid.classList.add('hidden');
        dom.noResults.classList.remove('hidden');
        dom.noResults.classList.add('flex'); // Ensure flex is added for centering
    } else {
        dom.grid.classList.remove('hidden');
        dom.noResults.classList.add('hidden');
        dom.noResults.classList.remove('flex');
        // Inject HTML
        dom.grid.innerHTML = filtered.map(createCard).join('');
    }
};

// --- 5. Event Listeners ---

// Filter: Category
dom.inputs.category.addEventListener('change', (e) => {
    state.filters.category = e.target.value;
    render();
});

// Filter: Location
dom.inputs.location.addEventListener('change', (e) => {
    state.filters.location = e.target.value;
    render();
});

// Filter: Budget
dom.inputs.budget.addEventListener('input', (e) => {
    const val = parseInt(e.target.value);
    state.filters.minBudget = val;
    dom.displays.budget.innerText = val === 0 ? '₹0+' : `> ${formatCurrency(val)}`;
    render();
});

// Sort
dom.inputs.sort.addEventListener('change', (e) => {
    state.sortBy = e.target.value;
    render();
});

// Clear/Reset Actions
const clearAll = () => {
    state.filters = { category: 'all', location: 'all', minBudget: 0 };
    state.sortBy = 'newest';

    // Reset UI Inputs
    dom.inputs.category.value = 'all';
    dom.inputs.location.value = 'all';
    dom.inputs.budget.value = 0;
    dom.inputs.sort.value = 'newest';
    dom.displays.budget.innerText = '₹0+';

    render();
};

dom.buttons.clear.addEventListener('click', clearAll);
dom.buttons.reset.addEventListener('click', clearAll);

// --- 6. Initial Render ---
render();

// Mobile Menu Toggle (Tailwind)
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const mobileNavLinks = document.querySelector('.nav-links-mobile');

mobileMenuBtn.addEventListener('click', () => {
    mobileNavLinks.classList.toggle('hidden');
    mobileNavLinks.classList.toggle('flex');
});
